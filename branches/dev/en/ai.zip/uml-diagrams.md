# UML Diagrams - MII IG ICU v2027.0.0

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **UML Diagrams**

## UML Diagrams

![](uml-7616e80bb8.png)

