# SD MII ICU Pulmonalvaskulaerer Widerstandsindex - MII IG ICU v2027.0.0

* [**Table of Contents**](toc.md)
* [**Profiles**](profiles.md)
* **SD MII ICU Pulmonalvaskulaerer Widerstandsindex**

## SD MII ICU Pulmonalvaskulaerer Widerstandsindex

Dieses Profil dient der spezialisierten Abbildung des pulmonalvaskulären Widerstandsindex in der Akutmedizin.

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

