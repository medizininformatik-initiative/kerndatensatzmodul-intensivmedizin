# MII PR ICU Bilanz Ausfuhr Magensonde - MII IG ICU v2027.0.0

* [**Table of Contents**](toc.md)
* [**Profiles**](profiles.md)
* **MII PR ICU Bilanz Ausfuhr Magensonde**

## MII PR ICU Bilanz Ausfuhr Magensonde

"Balance export gastric tube (Observation)" is a characteristic of the generic profile for [(Liquid) balances (Observation)](extern-mii-pr-icu-bilanz.md). See there for more detailed information regarding explanations of the items or reference of the entries in the FHIR resource to the Logical Model.

Dieses Profil wurde aus dem Modul KDS ICU entnommen und dient der Abbildung der Ausfuhr über eine Magensonde als Teil der Bilanzierung von Patienten. Es ermöglicht die Erfassung der Menge der Flüssigkeit, die ein Patient über eine Magensonde ausgeschieden hat, und bietet somit eine spezifische Lösung für die Dokumentation dieses Aspekts der Flüssigkeitsbilanz.

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

