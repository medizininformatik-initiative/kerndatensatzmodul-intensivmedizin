# Score Rass - MII IG ICU v2027.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Score Rass**

## Example Observation: Score Rass

-------

**English**

-------

Profile: [MII PR ICU Score RASS](https://simplifier.net/resolve?scope=de.gematik.isik@6.0.0&canonical=https://gematik.de/fhir/isik/StructureDefinition/mii-pr-icu-score-rass)

**status**: Final

**category**: Survey

**code**: Richmond Agitation Sedation Scale score (observable entity)

**subject**: [Ida Intensivbeispiel (official) Female, DoB: 1998-06-15 ( Medical record number)](Patient-mii-exa-icu-patient.md)

**effective**: 2021-12-06 00:52:00+0100

**value**: Alert and calm 0



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-icu-score-rass",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/mii-pr-icu-score-rass"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "version" : "2.0.0",
      "code" : "survey",
      "display" : "Survey"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "version" : "2.0.0",
      "code" : "exam",
      "display" : "Exam"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
      "code" : "1345050000",
      "display" : "Richmond Agitation Sedation Scale score (observable entity)"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-icu-patient",
    "type" : "Patient",
    "identifier" : {
      "system" : "http://example.com",
      "value" : "111"
    }
  },
  "effectiveDateTime" : "2021-12-06T00:52:00+01:00",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.83",
      "code" : "LA33962-4",
      "display" : "Alert and calm 0"
    }]
  }
}

```
