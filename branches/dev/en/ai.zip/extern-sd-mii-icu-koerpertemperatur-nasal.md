# SD MII ICU Koerpertemperatur nasal - MII IG ICU v2027.0.0

* [**Table of Contents**](toc.md)
* [**Profiles**](profiles.md)
* **SD MII ICU Koerpertemperatur nasal**

## SD MII ICU Koerpertemperatur nasal

Dieses Profil dient der spezialisierten Abbildung der Körpertemperaturmessung im Nasenbereich in der Akutmedizin. Es dient nicht der Abbildung der KörperKERNtemperatur (siehe dafür Profile zu Körperkerntemperatur im generischen Modul Vitalparameter bzw. abgeleitete Profile im ICU-Bereich).

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

