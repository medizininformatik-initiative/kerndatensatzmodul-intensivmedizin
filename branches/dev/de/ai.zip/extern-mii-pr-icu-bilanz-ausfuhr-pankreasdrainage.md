# MII PR ICU Bilanz Ausfuhr Pankreasdrainage - MII IG ICU v2027.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Profile**](profiles.md)
* **MII PR ICU Bilanz Ausfuhr Pankreasdrainage**

## MII PR ICU Bilanz Ausfuhr Pankreasdrainage

Dies ist eine Ausprägung des generischen Profils zu [Bilanz (Observation)](extern-mii-pr-icu-bilanz.md). Siehe dort für nähere Informationen hinsichtlich Erklärungen der Items, oder Bezug der Einträge in der FHIR-Ressource zum Logical Model.

Dieses Profil wurde aus dem Modul KDS ICU entnommen und dient der Abbildung der Ausfuhr über eine Pankreasdrainage als Teil der Bilanzierung von Patienten. Es ermöglicht die Erfassung der Menge der Flüssigkeit, die ein Patient über eine Pankreasdrainage ausgeschieden hat, und bietet somit eine spezifische Lösung für die Dokumentation dieses Aspekts der Flüssigkeitsbilanz.

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

