# Bilanz Kalorienbedarf Pro Tag - MII IG ICU v2027.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Bilanz Kalorienbedarf Pro Tag**

## Beispiel Observation: Bilanz Kalorienbedarf Pro Tag

-------

**German**

-------

Profile: [MII PR ICU Bilanz Kalorienbedarf pro Tag](StructureDefinition-mii-pr-icu-bilanz-kalorienbedarf-pro-tag.md)

**status**: Final

**code**: Calorie need 24 hour Estimated

**subject**: Synthetic example patient

**effective**: 2026-01-01 09:00:00+0100

**value**: 1800 kilocalorie per day (Details: UCUM codekcal/(24.h) = 'kcal/(24.h)')

**method**: Schofield equation



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-icu-bilanz-kalorienbedarf-pro-tag",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-bilanz-kalorienbedarf-pro-tag"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.83",
      "code" : "9058-9",
      "display" : "Calorie need 24 hour Estimated"
    }]
  },
  "subject" : {
    "display" : "Synthetic example patient"
  },
  "effectiveDateTime" : "2026-01-01T09:00:00+01:00",
  "valueQuantity" : {
    "value" : 1800,
    "unit" : "kilocalorie per day",
    "system" : "http://unitsofmeasure.org",
    "code" : "kcal/(24.h)"
  },
  "method" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
      "code" : "258090004",
      "display" : "Calculated"
    }],
    "text" : "Schofield equation"
  }
}

```
