# SD MII ICU Koerpergroesse Percentil - MII IG ICU v2027.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Profile**](profiles.md)
* **SD MII ICU Koerpergroesse Percentil**

## SD MII ICU Koerpergroesse Percentil

Dieses Profil dient der spezialisierten Abbildung des altersabhängigen Körpergrößen-Perzentils in der Akutmedizin.

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

