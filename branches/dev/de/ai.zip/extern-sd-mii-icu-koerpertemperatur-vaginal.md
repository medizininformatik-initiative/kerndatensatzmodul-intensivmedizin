# SD MII ICU Koerpertemperatur vaginal - MII IG ICU v2027.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Profile**](profiles.md)
* **SD MII ICU Koerpertemperatur vaginal**

## SD MII ICU Koerpertemperatur vaginal

Dieses Profil bietet eine spezialisierte Abbildung der geschätzten KörperKERNtemperatur gemessen vaginal in der Akutmedizin.

### Profile

How to read: [Reading StructureDefinitions](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).

* [Differential](#tabs-diff)
* [Snapshot](#tabs-snap)
* [Must Support](#tabs-ms)

### Definitions

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

