# MII VS ICU Code Procedure Beatmung SNOMED - MII IG ICU v2027.0.0-ballot.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS ICU Code Procedure Beatmung SNOMED**

## ValueSet: MII VS ICU Code Procedure Beatmung SNOMED 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-procedure-beatmung-snomed | *Version*:2027.0.0-ballot.3 |
| Active Stand: 2025-02-11 | *Maschinenlesbarer Name*:MII_VS_ICU_Code_Procedure_Beatmung_SNOMED |

 **References** 

* [MII PR ICU Beatmung](StructureDefinition-mii-pr-icu-beatmung.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-procedure-beatmung-snomed",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-procedure-beatmung-snomed",
  "version" : "2027.0.0-ballot.3",
  "name" : "MII_VS_ICU_Code_Procedure_Beatmung_SNOMED",
  "title" : "MII VS ICU Code Procedure Beatmung SNOMED",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-11",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "1149092001",
        "display" : "Positive pressure airway ventilation (regime/therapy)"
      },
      {
        "code" : "53950000",
        "display" : "Respiratory therapy (procedure)"
      },
      {
        "code" : "243141005",
        "display" : "Mechanically assisted spontaneous ventilation (regime/therapy)"
      },
      {
        "code" : "11140008",
        "display" : "Respiratory assist, manual (procedure)"
      },
      {
        "code" : "428311008",
        "display" : "Non-invasive ventilation (regime/therapy)"
      },
      {
        "code" : "243160003",
        "display" : "Control of end expiratory pressure (procedure)"
      },
      {
        "code" : "33050008",
        "display" : "Pulmonary resuscitation (procedure)"
      },
      {
        "code" : "229306004",
        "display" : "Positive airway pressure therapy (regime/therapy)"
      },
      {
        "code" : "243180002",
        "display" : "Expired air ventilation (procedure)"
      },
      {
        "code" : "243161004",
        "display" : "Positive end expiratory pressure increased (procedure)"
      },
      {
        "code" : "243164007",
        "display" : "Positive end expiratory pressure reduced (procedure)"
      },
      {
        "code" : "59427005",
        "display" : "Synchronized intermittent mandatory ventilation (regime/therapy)"
      },
      {
        "code" : "47545007",
        "display" : "Continuous positive airway pressure ventilation treatment (regime/therapy)"
      },
      {
        "code" : "243142003",
        "display" : "Dual pressure spontaneous ventilation support(regime/therapy)"
      },
      {
        "code" : "37113006",
        "display" : "Mouth-to-mouth resuscitation (procedure)"
      },
      {
        "code" : "243157005",
        "display" : "Liquid ventilation (regime/therapy)"
      },
      {
        "code" : "243170001",
        "display" : "Negative end expiratory pressure applied (procedure)"
      },
      {
        "code" : "371908008",
        "display" : "Oxygen administration by mask (procedure)"
      },
      {
        "code" : "243162006",
        "display" : "Positive end expiratory pressure increased to optimal positive end expiratory pressure (procedure)"
      },
      {
        "code" : "243166009",
        "display" : "Positive end expiratory pressure reduced to optimal positive end expiratory pressure (procedure)"
      },
      {
        "code" : "243168005",
        "display" : "Positive end expiratory pressure withdrawn (procedure)"
      },
      {
        "code" : "243150007",
        "display" : "Assist control ventilation (regime/therapy)"
      },
      {
        "code" : "243154003",
        "display" : "High frequency jet ventilation (regime/therapy)"
      },
      {
        "code" : "243155002",
        "display" : "High frequency oscillatory ventilation (regime/therapy)"
      },
      {
        "code" : "243153009",
        "display" : "High frequency positive pressure ventilation (regime/therapy)"
      },
      {
        "code" : "448442005",
        "display" : "Transtracheal jet ventilation (procedure)"
      },
      {
        "code" : "4764004",
        "display" : "Jet ventilation procedure (procedure)"
      },
      {
        "code" : "243143008",
        "display" : "Airway pressure release ventilation (regime/therapy)"
      },
      {
        "code" : "448134000",
        "display" : "Continuous positive airway pressure to nonventilated lung (regime/therapy)"
      },
      {
        "code" : "34281000175105",
        "display" : "Nocturnal continuous positive airway pressure (regime/therapy)"
      },
      {
        "code" : "34291000175108",
        "display" : "Nocturnal dual pressure spontaneous ventilation support (regime/therapy)"
      },
      {
        "code" : "229312009",
        "display" : "Nasal ventilation therapy (regime/therapy)"
      },
      {
        "code" : "243140006",
        "display" : "Lung inflation by intermittent compression of reservoir bag (procedure)"
      },
      {
        "code" : "229313004",
        "display" : "Manual hyperinflation (procedure)"
      },
      {
        "code" : "425696007",
        "display" : "Manual respiratory assistance using bag and mask (procedure)"
      },
      {
        "code" : "243184006",
        "display" : "Ventilation with self-inflating bag (procedure)"
      },
      {
        "code" : "74596007",
        "display" : "Resuscitation with artificial ventilation (procedure)"
      },
      {
        "code" : "243181003",
        "display" : "Expired air ventilation with airway aid (procedure)"
      },
      {
        "code" : "243183000",
        "display" : "Mouth to nose expired air ventilation (procedure)"
      },
      {
        "code" : "243182005",
        "display" : "Mouth to mouth expired air ventilation with airway (procedure)"
      },
      {
        "code" : "52729008",
        "display" : "Treatment by iron lung (regime/therapy)"
      },
      {
        "code" : "76777009",
        "display" : "Artificial respiration by electrophrenic stimulation (regime/therapy)"
      },
      {
        "code" : "281508008",
        "display" : "Cuirasse ventilation (regime/therapy)"
      },
      {
        "code" : "276737004",
        "display" : "Domiciliary ventilation (regime/therapy)"
      },
      {
        "code" : "276732005",
        "display" : "Apneic oxygenation (procedure)"
      },
      {
        "code" : "243159008",
        "display" : "Intermittent negative pressure ventilation (regime/therapy)"
      },
      {
        "code" : "243158000",
        "display" : "Fluorocarbon ventilation (regime/therapy)"
      },
      {
        "code" : "243172009",
        "display" : "Negative end expiratory pressure decreased (procedure)"
      },
      {
        "code" : "243171002",
        "display" : "Negative end expiratory pressure increased (procedure)"
      },
      {
        "code" : "82433009",
        "display" : "Continuous negative pressure ventilation treatment (regime/therapy)"
      },
      {
        "code" : "447837008",
        "display" : "Non-invasive positive pressure ventilation (regime/therapy)"
      },
      {
        "code" : "870392006",
        "display" : "Weaning from noninvasive ventilation (regime/therapy)"
      },
      {
        "code" : "243146000",
        "display" : "Diaphragmatic augmentation by rocking bed (procedure)"
      },
      {
        "code" : "429253002",
        "display" : "Oxygen administration by Venturi mask (procedure)"
      },
      {
        "code" : "371907003",
        "display" : "Oxygen administration by nasal cannula (procedure)"
      },
      {
        "code" : "398077001",
        "display" : "Oxygen dynamic interventions (procedure)"
      },
      {
        "code" : "182714002",
        "display" : "Oxygenator therapy (procedure)"
      },
      {
        "code" : "243136002",
        "display" : "Short-term oxygen therapy (procedure)"
      },
      {
        "code" : "315041000",
        "display" : "High concentration oxygen therapy (procedure)"
      },
      {
        "code" : "426990007",
        "display" : "Home oxygen therapy (procedure)"
      },
      {
        "code" : "304577004",
        "display" : "Humidified oxygen therapy (procedure)"
      },
      {
        "code" : "870533002",
        "display" : "Heated and humidified high flow oxygen therapy (procedure)"
      },
      {
        "code" : "71786000",
        "display" : "Intranasal oxygen therapy (procedure)"
      },
      {
        "code" : "1259025002",
        "display" : "Heated and humidified high flow oxygen therapy using nasal cannula (procedure)"
      },
      {
        "code" : "1186622005",
        "display" : "Synchronized intermittent mandatory ventilation - pressure-control pressure-support inflation (regime/therapy)"
      },
      {
        "code" : "1259864003",
        "display" : "Pressure support ventilation (regime/therapy)"
      },
      {
        "code" : "266700009",
        "display" : "Assisted breathing (regime/therapy)"
      },
      {
        "code" : "40617009",
        "display" : "Artificial ventilation (regime/therapy)"
      },
      {
        "code" : "1186618000",
        "display" : "Bilevel artificial ventilation (regime/therapy)"
      },
      {
        "code" : "1186620002",
        "display" : "Minimum minute volume ventilation (regime/therapy)"
      },
      {
        "code" : "870391004",
        "display" : "Assisted ventilation in prone position (regime/therapy)"
      },
      {
        "code" : "787180006",
        "display" : "Mechanical insufflation exsufflation (regime/therapy)"
      },
      {
        "code" : "424172009",
        "display" : "Dual pressure spontaneous ventilation support weaning protocol (regime/therapy)"
      },
      {
        "code" : "182686001",
        "display" : "Endotracheal respiratory assistance (procedure)"
      },
      {
        "code" : "243137006",
        "display" : "Long-term oxygen therapy (procedure)"
      },
      {
        "code" : "1336169000",
        "display" : "Low flow oxygen delivery (procedure)"
      },
      {
        "code" : "387727008",
        "display" : "Intermittent positive pressure breathing treatment (regime/therapy)"
      },
      {
        "code" : "19861002",
        "display" : "Intermittent positive pressure breathing treatment with nebulized medication (regime/therapy)"
      },
      {
        "code" : "387726004",
        "display" : "Intermittent positive pressure breathing treatment without nebulized medication (regime/therapy)"
      },
      {
        "code" : "1258985005",
        "display" : "Invasive mechanical ventilation (regime/therapy)"
      },
      {
        "code" : "1297240007",
        "display" : "Neurally adjusted ventilatory assist (regime/therapy)"
      },
      {
        "code" : "1197610004",
        "display" : "Positive pressure ventilation via bag and mask (regime/therapy)"
      }]
    }]
  }
}

```
