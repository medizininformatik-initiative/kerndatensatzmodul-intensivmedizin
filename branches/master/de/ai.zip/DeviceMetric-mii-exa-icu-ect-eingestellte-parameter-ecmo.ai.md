# Ect Eingestellte Parameter Ecmo - MII IG ICU v2027.0.0-ballot.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Ect Eingestellte Parameter Ecmo**

## Beispiel DeviceMetric: Ect Eingestellte Parameter Ecmo

-------

**German**

-------

Profile: [MII PR ICU DeviceMetric Eingestellte Gemessene Parameter Extrakorporale Verfahren](StructureDefinition-mii-pr-icu-dm-eingest-gem-parameter-extrakorporale-verfahren.md)

**type**: Extracorporeal circulation procedure (procedure)

**category**: Setting



## Resource Content

```json
{
  "resourceType" : "DeviceMetric",
  "id" : "mii-exa-icu-ect-eingestellte-parameter-ecmo",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-dm-eingest-gem-parameter-extrakorporale-verfahren"]
  },
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "182744004",
      "display" : "Extracorporeal circulation procedure (procedure)"
    }]
  },
  "category" : "setting"
}

```
