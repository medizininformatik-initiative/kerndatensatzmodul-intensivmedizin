# Score Numerische Ratingskala - MII IG ICU v2027.0.0-ballot.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Score Numerische Ratingskala**

## Beispiel Observation: Score Numerische Ratingskala

-------

**German**

-------

Profile: [MII PR ICU Score Numerische Ratingskala](StructureDefinition-mii-pr-icu-score-numerische-ratingskala.md)

**status**: Final

**category**: Survey, Assessment scales (assessment scale)

**code**: Numeric Pain Rating Scale score

**subject**: Identifier: `http://example.com`/1234

**effective**: 2021-12-06 00:52:00+0100

**value**: 3



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-icu-score-numerische-ratingskala",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-score-numerische-ratingskala"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "survey",
      "display" : "Survey"
    }]
  },
  {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "273249006",
      "display" : "Assessment scales (assessment scale)"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "1284857008"
    }]
  },
  "subject" : {
    "type" : "Patient",
    "identifier" : {
      "system" : "http://example.com",
      "value" : "1234"
    }
  },
  "effectiveDateTime" : "2021-12-06T00:52:00+01:00",
  "valueInteger" : 3
}

```
