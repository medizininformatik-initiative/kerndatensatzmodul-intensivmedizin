# MII VS ICU Code Extrakorporale Verfahren - MII IG ICU v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS ICU Code Extrakorporale Verfahren**

## ValueSet: MII VS ICU Code Extrakorporale Verfahren 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-extrakorporale-verfahren | *Version*:2027.0.0-ballot.rc1 |
| Active as of 2025-02-11 | *Computable Name*:MII_VS_ICU_Code_Extrakorporale_Verfahren |

 
Mögliche Codes für extrakorporale Verfahren. Für die Einteilung und Interpretation in Bezug auf unterschiedliche Detail-Level beachte den zugehörigen implementationguide. 

 **References** 

* [MII PR ICU Extrakorporales Verfahren](StructureDefinition-mii-pr-icu-extrakorporales-verfahren.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-extrakorporale-verfahren",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-extrakorporale-verfahren",
  "version" : "2027.0.0-ballot.rc1",
  "name" : "MII_VS_ICU_Code_Extrakorporale_Verfahren",
  "title" : "MII VS ICU Code Extrakorporale Verfahren",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-11",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mögliche Codes für extrakorporale Verfahren. Für die Einteilung und Interpretation in Bezug auf unterschiedliche Detail-Level beachte den zugehörigen implementationguide.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "265764009",
        "display" : "Renal dialysis (procedure)"
      },
      {
        "code" : "341939001",
        "display" : "Extracorporeal hemofiltration (procedure)"
      },
      {
        "code" : "127788007",
        "display" : "Apheresis (procedure)"
      },
      {
        "code" : "233572003",
        "display" : "Extracorporeal gas exchange (procedure)"
      },
      {
        "code" : "302497006",
        "display" : "Hemodialysis (procedure)"
      },
      {
        "code" : "233586004",
        "display" : "Hemodiafiltration (procedure)"
      },
      {
        "code" : "233581009",
        "display" : "Hemofiltration (procedure)"
      },
      {
        "code" : "182750009",
        "display" : "Ultrafiltration (procedure)"
      },
      {
        "code" : "714749008",
        "display" : "Continuous renal replacement therapy (procedure)"
      },
      {
        "code" : "233573008",
        "display" : "Extracorporeal membrane oxygenation (procedure)"
      },
      {
        "code" : "233578004",
        "display" : "Continuous hemodialysis (procedure)"
      },
      {
        "code" : "233575001",
        "display" : "Intermittent hemodialysis (procedure)"
      },
      {
        "code" : "233588003",
        "display" : "Continuous hemodiafiltration (procedure)"
      },
      {
        "code" : "233583007",
        "display" : "Continuous hemofiltration (procedure)"
      },
      {
        "code" : "233594006",
        "display" : "Lipopheresis (procedure)"
      },
      {
        "code" : "72541002",
        "display" : "Plateletpheresis (procedure)"
      },
      {
        "code" : "233574002",
        "display" : "Extracorporeal carbon dioxide removal (procedure)"
      },
      {
        "code" : "786452006",
        "display" : "Arteriovenous extracorporeal membrane oxygenation (procedure)"
      },
      {
        "code" : "786451004",
        "display" : "Venoarterial extracorporeal membrane oxygenation (procedure)"
      },
      {
        "code" : "786453001",
        "display" : "Venovenous extracorporeal membrane oxygenation (procedure)"
      },
      {
        "code" : "233579007",
        "display" : "Continuous arteriovenous hemodialysis (procedure)"
      },
      {
        "code" : "233580005",
        "display" : "Continuous venovenous hemodialysis (procedure)"
      },
      {
        "code" : "708932005",
        "display" : "Emergency hemodialysis (procedure)"
      },
      {
        "code" : "427053002",
        "display" : "Extracorporeal albumin hemodialysis (procedure)"
      },
      {
        "code" : "57274006",
        "display" : "Initial hemodialysis (procedure)"
      },
      {
        "code" : "233577009",
        "display" : "Intermittent hemodialysis with continuous ultrafiltration (procedure)"
      },
      {
        "code" : "233576000",
        "display" : "Intermittent hemodialysis with sequential ultrafiltration (procedure)"
      },
      {
        "code" : "11932001",
        "display" : "Stabilizing hemodialysis (procedure)"
      },
      {
        "code" : "698074000",
        "display" : "Sustained low-efficiency dialysis (procedure)"
      },
      {
        "code" : "233589006",
        "display" : "Continuous arteriovenous hemodiafiltration (procedure)"
      },
      {
        "code" : "233590002",
        "display" : "Continuous venovenous hemodiafiltration (procedure)"
      },
      {
        "code" : "708933000",
        "display" : "Emergency hemodiafiltration (procedure)"
      },
      {
        "code" : "233587008",
        "display" : "Intermittent hemodiafiltration (procedure)"
      },
      {
        "code" : "708930002",
        "display" : "Maintenance hemodiafiltration (procedure)"
      },
      {
        "code" : "233584001",
        "display" : "Continuous arteriovenous hemofiltration (procedure)"
      },
      {
        "code" : "233585000",
        "display" : "Continuous venovenous hemofiltration (procedure)"
      },
      {
        "code" : "715743002",
        "display" : "Emergency hemofiltration (procedure)"
      },
      {
        "code" : "233582002",
        "display" : "Intermittent hemofiltration (procedure)"
      },
      {
        "code" : "708934006",
        "display" : "Maintenance hemofiltration (procedure)"
      },
      {
        "code" : "14130001000004103",
        "display" : "Aquapheresis (procedure)"
      },
      {
        "code" : "182749009",
        "display" : "Extracorporeal blood irradiation (procedure)"
      },
      {
        "code" : "438839005",
        "display" : "Erythrocytapheresis (procedure)"
      },
      {
        "code" : "83794005",
        "display" : "Extracorporeal photopheresis (procedure)"
      },
      {
        "code" : "77257005",
        "display" : "Leukopheresis (procedure)"
      },
      {
        "code" : "448955002",
        "display" : "Low density lipoprotein apheresis (procedure)"
      },
      {
        "code" : "20720000",
        "display" : "Plasmapheresis (procedure)"
      },
      {
        "code" : "233564000",
        "display" : "Platelet apheresis using human leukocyte antigen matched donors (procedure)"
      },
      {
        "code" : "233565004",
        "display" : "Platelet apheresis using random donors (procedure)"
      },
      {
        "code" : "225067007",
        "display" : "Therapeutic plasma exchange (procedure)"
      },
      {
        "code" : "19647005",
        "display" : "Therapeutic plasmapheresis using plasma as the major replacement fluid (procedure)"
      }]
    }]
  }
}

```
