# MII VS ICU Code Observation Pupillengroesse - MII IG ICU v2027.0.0-ballot.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS ICU Code Observation Pupillengroesse**

## ValueSet: MII VS ICU Code Observation Pupillengroesse 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-observation-pupillengroesse | *Version*:2027.0.0-ballot.3 |
| Active Stand: 2025-12-16 | *Maschinenlesbarer Name*:MII_VS_ICU_Code_Observation_Pupillengroesse |

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unsupported Code System Version)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-observation-pupillengroesse",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-observation-pupillengroesse",
  "version" : "2027.0.0-ballot.3",
  "name" : "MII_VS_ICU_Code_Observation_Pupillengroesse",
  "title" : "MII VS ICU Code Observation Pupillengroesse",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-16",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "420335002",
        "display" : "Medium size pupil"
      },
      {
        "code" : "301939004",
        "display" : "Constricted pupil"
      },
      {
        "code" : "188557000",
        "display" : "Large pupil"
      }]
    }]
  }
}

```
