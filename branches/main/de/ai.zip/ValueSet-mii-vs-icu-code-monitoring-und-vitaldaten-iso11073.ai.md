# MII VS ICU Code Monitoring und Vitaldaten ISO11073 - MII IG ICU v2027.0.0-ballot.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS ICU Code Monitoring und Vitaldaten ISO11073**

## ValueSet: MII VS ICU Code Monitoring und Vitaldaten ISO11073 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-monitoring-und-vitaldaten-iso11073 | *Version*:2027.0.0-ballot.3 |
| Active Stand: 2025-02-11 | *Maschinenlesbarer Name*:MII_VS_ICU_Code_Monitoring_und_Vitaldaten_ISO11073 |

 
Dieses ValueSet enthält Codes für Vitaldaten sowie Daten aus dem Patientenmonitoring. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-monitoring-und-vitaldaten-iso11073",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-monitoring-und-vitaldaten-iso11073",
  "version" : "2027.0.0-ballot.3",
  "name" : "MII_VS_ICU_Code_Monitoring_und_Vitaldaten_ISO11073",
  "title" : "MII VS ICU Code Monitoring und Vitaldaten ISO11073",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-11",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Dieses ValueSet enthält Codes für Vitaldaten sowie Daten aus dem Patientenmonitoring.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "urn:iso:std:iso:11073:10101",
      "concept" : [{
        "code" : "150017",
        "display" : "Systolic blood pressure"
      },
      {
        "code" : "150019",
        "display" : "Mean blood pressure"
      },
      {
        "code" : "150018",
        "display" : "Diastolic blood pressure"
      },
      {
        "code" : "150084",
        "display" : "Central venous pressure"
      },
      {
        "code" : "150045",
        "display" : "Systolic pulmonary arterial pressure"
      },
      {
        "code" : "150047",
        "display" : "Mean pulmonary arterial pressure"
      },
      {
        "code" : "150046",
        "display" : "Diastolic pulmonary arterial pressure"
      },
      {
        "code" : "150052",
        "display" : "Pulmonary artery wedge pressure"
      },
      {
        "code" : "150276",
        "display" : "Cardiac output"
      },
      {
        "code" : "149772",
        "display" : "Cardiac index"
      },
      {
        "code" : "149760",
        "display" : "Systemic vascular resistance indexed"
      },
      {
        "code" : "152852",
        "display" : "Pulmonary Vascular Resistance Index"
      },
      {
        "code" : "150428",
        "display" : "Ventricular stroke"
      },
      {
        "code" : "149764",
        "display" : "Left Ventricular Stroke Work Index"
      },
      {
        "code" : "150368",
        "display" : "Body temperature - Core"
      },
      {
        "code" : "150456",
        "display" : "Oxygen saturation in Arterial blood by Pulse oximetry"
      },
      {
        "code" : "160300",
        "display" : "Postductal SpO2"
      },
      {
        "code" : "160296",
        "display" : "Preductal SpO2"
      },
      {
        "code" : "153608",
        "display" : "Intracranial pressure"
      },
      {
        "code" : "150103",
        "display" : "Mean left ventricular pressure"
      },
      {
        "code" : "150107",
        "display" : "Mean right ventricular pressure"
      },
      {
        "code" : "150101",
        "display" : "Systolic left ventricular pressure"
      },
      {
        "code" : "150105",
        "display" : "Systolic right ventricular pressure"
      },
      {
        "code" : "150102",
        "display" : "Diastolic left ventricular pressure"
      },
      {
        "code" : "150106",
        "display" : "Diastolic right ventricular pressure"
      },
      {
        "code" : "150069",
        "display" : "Systolic right atrial pressure"
      },
      {
        "code" : "150065",
        "display" : "Systolic left atrial pressure"
      },
      {
        "code" : "150067",
        "display" : "Mean left atrial pressure"
      },
      {
        "code" : "150071",
        "display" : "Mean right atrial pressure"
      },
      {
        "code" : "150066",
        "display" : "Diastolic left atrial pressure"
      },
      {
        "code" : "150070",
        "display" : "Diastolic right atrial pressure"
      },
      {
        "code" : "188420",
        "display" : "Rectal temperature"
      },
      {
        "code" : "188496",
        "display" : "Axillary temperature"
      },
      {
        "code" : "188424",
        "display" : "Oral temperature"
      },
      {
        "code" : "188436",
        "display" : "Blood temperature"
      },
      {
        "code" : "188500",
        "display" : "Myocardial temperature"
      },
      {
        "code" : "147842",
        "display" : "Heart Rate"
      },
      {
        "code" : "188504",
        "display" : "Nasal temperature"
      },
      {
        "code" : "149514",
        "display" : "Pulse rate"
      },
      {
        "code" : "150380",
        "display" : "Nasopharynx temperature"
      },
      {
        "code" : "188452",
        "display" : "Axillary (armpit) temperature"
      },
      {
        "code" : "150324"
      },
      {
        "code" : "150372"
      },
      {
        "code" : "188796",
        "display" : "Ideal body weight (IBW)"
      },
      {
        "code" : "150392"
      },
      {
        "code" : "150356",
        "display" : "Airway temperature"
      }]
    }]
  }
}

```
