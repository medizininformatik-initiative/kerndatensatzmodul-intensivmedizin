# Muv Koerpertemperatur Nasen Rachen Raum - MII IG ICU v2027.0.0-ballot.3-rc.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Muv Koerpertemperatur Nasen Rachen Raum**

## Beispiel Observation: Muv Koerpertemperatur Nasen Rachen Raum

-------

**German**

-------

Profile: [SD MII ICU Koerpertemperatur Nasen-Rachen-Raum](https://simplifier.net/resolve?scope=de.gematik.isik@6.0.0&canonical=https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-koerpertemperatur-nasen-rachen-raum)

**status**: Final

**category**: Vital Signs

**code**: Core body temperature measured in nasopharynx

**subject**: [Ida Intensivbeispiel (official) Female, DoB: 1998-06-15 ( Krankenaktennummer)](Patient-mii-exa-icu-patient.md)

**effective**: 2019-12-23 09:30:10+0100 --> 2019-12-23 10:30:10+0100

**value**: 37 degree Celsius (Details: UCUM codeCel = 'Cel')

**bodySite**: Nasopharyngeal structure (body structure)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-icu-muv-koerpertemperatur-nasen-rachen-raum",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/sd-mii-icu-koerpertemperatur-nasen-rachen-raum"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "698831002",
      "display" : "Core body temperature measured in nasopharynx"
    },
    {
      "system" : "http://loinc.org",
      "code" : "60838-0",
      "display" : "Body temperature"
    },
    {
      "system" : "urn:iso:std:iso:11073:10101",
      "code" : "150380",
      "display" : "Nasopharynx temperature"
    },
    {
      "system" : "http://loinc.org",
      "code" : "8310-5"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-icu-patient"
  },
  "effectivePeriod" : {
    "start" : "2019-12-23T09:30:10+01:00",
    "end" : "2019-12-23T10:30:10+01:00"
  },
  "valueQuantity" : {
    "value" : 37,
    "unit" : "degree Celsius",
    "system" : "http://unitsofmeasure.org",
    "code" : "Cel"
  },
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "71836000",
      "display" : "Nasopharyngeal structure (body structure)"
    }]
  }
}

```
