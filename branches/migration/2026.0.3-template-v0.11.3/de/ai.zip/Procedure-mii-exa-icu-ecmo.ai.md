# Ecmo - MII IG ICU v2027.0.0-ballot.rc1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Ecmo**

## Beispiel Procedure: Ecmo

-------

**German**

-------

Profile: [MII PR ICU Extrakorporales Verfahren](StructureDefinition-mii-pr-icu-extrakorporales-verfahren.md)

**status**: Completed

**category**: Procedure

**code**: Venovenous extracorporeal membrane oxygenation (procedure)

**subject**: Identifier: `http://example.com`/1234

**encounter**: Identifier: `http://example.com`/5678

**performed**: 2021-12-06 00:52:00+0100 --> 2021-12-06 14:34:00+0100



## Resource Content

```json
{
  "resourceType" : "Procedure",
  "id" : "mii-exa-icu-ecmo",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-extrakorporales-verfahren"]
  },
  "status" : "completed",
  "category" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "procedure",
      "display" : "Procedure"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20241101",
      "code" : "786453001",
      "display" : "Venovenous extracorporeal membrane oxygenation (procedure)"
    }]
  },
  "subject" : {
    "type" : "Patient",
    "identifier" : {
      "system" : "http://example.com",
      "value" : "1234"
    }
  },
  "encounter" : {
    "type" : "Encounter",
    "identifier" : {
      "system" : "http://example.com",
      "value" : "5678"
    }
  },
  "performedPeriod" : {
    "start" : "2021-12-06T00:52:00+01:00",
    "end" : "2021-12-06T14:34:00+01:00"
  }
}

```
