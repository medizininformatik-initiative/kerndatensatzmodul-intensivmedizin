# MII VS ICU Code Observation Pupillensymmetrie - MII IG ICU v2027.0.0-ballot.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS ICU Code Observation Pupillensymmetrie**

## ValueSet: MII VS ICU Code Observation Pupillensymmetrie 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-observation-pupillensymmetrie | *Version*:2027.0.0-ballot.3 |
| Active as of 2025-12-16 | *Computable Name*:MII_VS_ICU_Code_Observation_Pupillensymmetrie |

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-code-observation-pupillensymmetrie",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-code-observation-pupillensymmetrie",
  "version" : "2027.0.0-ballot.3",
  "name" : "MII_VS_ICU_Code_Observation_Pupillensymmetrie",
  "title" : "MII VS ICU Code Observation Pupillensymmetrie",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-16",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "301943000",
        "display" : "Pupils equal (finding)"
      },
      {
        "code" : "13045009",
        "display" : "Anisocoria (disorder)"
      }]
    }]
  }
}

```
