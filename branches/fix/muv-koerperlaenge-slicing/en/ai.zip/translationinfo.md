# Translation Information - MII IG ICU v2027.0.0-ballot.3

* [**Table of Contents**](toc.md)
* **Translation Information**

## Translation Information

This guide is written in **English** (the default language); **German** is the translation. English is therefore both the base rendering of the guide and the `/en/` rendering; use the language switcher at the top right to move between `/en/` and `/de/`.

Translated pages live under `input/translations/de/pagecontent/` (same file name as the English page); resource translations are `.po` files under `input/translations/de/`. Details: [`docs/recipes/add-translation.md`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-intensivmedizin/blob/main/docs/recipes/add-translation.md) in this repository.

> [TODO: Record which parts of your module are already translated into German.]

