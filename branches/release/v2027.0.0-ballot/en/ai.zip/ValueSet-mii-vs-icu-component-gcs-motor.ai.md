# MII VS ICU Component GCS Motor - MII IG ICU v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS ICU Component GCS Motor**

## ValueSet: MII VS ICU Component GCS Motor 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-component-gcs-motor | *Version*:2027.0.0-ballot |
| Active as of 2026-07-28 | *Computable Name*:MII_VS_ICU_Component_GCS_Motor |

 **References** 

* [MII PR ICU Score GCS](StructureDefinition-mii-pr-icu-score-gcs.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-icu-component-gcs-motor",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/ValueSet/mii-vs-icu-component-gcs-motor",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_ICU_Component_GCS_Motor",
  "title" : "MII VS ICU Component GCS Motor",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-28",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "LA6562-8",
        "display" : "No motor response"
      },
      {
        "code" : "LA6563-6",
        "display" : "Extension to pain"
      },
      {
        "code" : "LA6564-4",
        "display" : "Flexion to pain"
      },
      {
        "code" : "LA6565-1",
        "display" : "Withdrawal from pain"
      },
      {
        "code" : "LA6566-9",
        "display" : "Localizing pain"
      },
      {
        "code" : "LA6567-7",
        "display" : "Obeys commands"
      }]
    }]
  }
}

```
