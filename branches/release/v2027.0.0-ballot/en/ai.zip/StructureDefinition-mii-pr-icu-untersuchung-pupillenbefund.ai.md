# MII PR ICU Untersuchung Pupillenbefund - MII IG ICU v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII PR ICU Untersuchung Pupillenbefund**

## Resource Profile: MII PR ICU Untersuchung Pupillenbefund 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund | *Version*:2027.0.0-ballot |
| Draft as of 2026-09-14 | *Computable Name*:MII_PR_ICU_Untersuchung_Pupillenbefund |

**Usages:**

* Examples for this Profile: [Observation/mii-exa-icu-untersuchung-pupillenbefund](Observation-mii-exa-icu-untersuchung-pupillenbefund.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.icu|current/StructureDefinition/StructureDefinition-mii-pr-icu-untersuchung-pupillenbefund.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-pr-icu-untersuchung-pupillenbefund.csv), [Excel](../StructureDefinition-mii-pr-icu-untersuchung-pupillenbefund.xlsx), [Schematron](../StructureDefinition-mii-pr-icu-untersuchung-pupillenbefund.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-icu-untersuchung-pupillenbefund",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenbefund",
  "version" : "2027.0.0-ballot",
  "name" : "MII_PR_ICU_Untersuchung_Pupillenbefund",
  "title" : "MII PR ICU Untersuchung Pupillenbefund",
  "status" : "draft",
  "date" : "2026-09-14T15:50:09+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.id",
      "path" : "Observation.id",
      "mustSupport" : true
    },
    {
      "id" : "Observation.meta",
      "path" : "Observation.meta",
      "mustSupport" : true
    },
    {
      "id" : "Observation.identifier",
      "path" : "Observation.identifier",
      "mustSupport" : true
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.category.coding.system",
      "path" : "Observation.category.coding.system",
      "patternUri" : "http://terminology.hl7.org/CodeSystem/observation-category"
    },
    {
      "id" : "Observation.category.coding.code",
      "path" : "Observation.category.coding.code",
      "patternCode" : "exam"
    },
    {
      "id" : "Observation.category.coding.display",
      "path" : "Observation.category.coding.display",
      "patternString" : "Exam"
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding",
      "path" : "Observation.code.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "closed"
      },
      "min" : 2,
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:Snomed",
      "path" : "Observation.code.coding",
      "sliceName" : "Snomed",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:Snomed.system",
      "path" : "Observation.code.coding.system",
      "fixedUri" : "http://snomed.info/sct"
    },
    {
      "id" : "Observation.code.coding:Snomed.code",
      "path" : "Observation.code.coding.code",
      "fixedCode" : "247010007"
    },
    {
      "id" : "Observation.code.coding:Snomed.display",
      "path" : "Observation.code.coding.display",
      "patternString" : "Pupil finding (finding)"
    },
    {
      "id" : "Observation.code.coding:Loinc",
      "path" : "Observation.code.coding",
      "sliceName" : "Loinc",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding:Loinc.system",
      "path" : "Observation.code.coding.system",
      "fixedUri" : "http://loinc.org"
    },
    {
      "id" : "Observation.code.coding:Loinc.code",
      "path" : "Observation.code.coding.code",
      "fixedCode" : "80310-6"
    },
    {
      "id" : "Observation.code.coding:Loinc.display",
      "path" : "Observation.code.coding.display",
      "patternString" : "Pupil assessment panel"
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "max" : "0",
      "mustSupport" : true
    },
    {
      "id" : "Observation.dataAbsentReason",
      "path" : "Observation.dataAbsentReason",
      "max" : "0",
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resolve()"
        }],
        "rules" : "closed"
      },
      "short" : "Referenzen auf die Mitgliedsbeobachtungen der Pupillenuntersuchung.",
      "comment" : "Dieses Panel bündelt die Einzelbefunde zur Pupillenuntersuchung via hasMember. Erwartet werden genau 9 Members: direkte und indirekte Lichtreaktion (je 2, links/rechts), Pupillengroesse (2), Pupillenform (2) und Pupillensymmetrie (1). Keine zusätzliche Interpretation im Panel selbst.",
      "min" : 9,
      "max" : "9",
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:PupillenlichtreaktionDirekt",
      "path" : "Observation.hasMember",
      "sliceName" : "PupillenlichtreaktionDirekt",
      "short" : "Mitgliedsbeobachtung: direkte Pupillenlichtreaktion pro Auge (2 Instanzen: links/rechts).",
      "min" : 2,
      "max" : "2",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-direkt"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:PupillenlichtreaktionIndirekt",
      "path" : "Observation.hasMember",
      "sliceName" : "PupillenlichtreaktionIndirekt",
      "short" : "Mitgliedsbeobachtung: indirekte Pupillenlichtreaktion pro Auge (2 Instanzen: links/rechts).",
      "min" : 2,
      "max" : "2",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenlichtreaktion-indirekt"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:Pupillengroesse",
      "path" : "Observation.hasMember",
      "sliceName" : "Pupillengroesse",
      "short" : "Mitgliedsbeobachtung: Pupillengroesse (beide Pupillen).",
      "min" : 2,
      "max" : "2",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillengroesse"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:Pupillenform",
      "path" : "Observation.hasMember",
      "sliceName" : "Pupillenform",
      "short" : "Mitgliedsbeobachtung: Pupillenform/Regularitaet (beide Pupillen).",
      "min" : 2,
      "max" : "2",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillenform"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:Pupillensymmetrie",
      "path" : "Observation.hasMember",
      "sliceName" : "Pupillensymmetrie",
      "short" : "Mitgliedsbeobachtung: Pupillensymmetrie (isokor/anisokor).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-icu/StructureDefinition/mii-pr-icu-untersuchung-pupillensymmetrie"]
      }],
      "mustSupport" : true
    }]
  }
}

```
